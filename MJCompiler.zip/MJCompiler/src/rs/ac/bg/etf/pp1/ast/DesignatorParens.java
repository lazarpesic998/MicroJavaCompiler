// generated with ast extension for cup
// version 0.8
// 17/2/2022 21:43:24


package rs.ac.bg.etf.pp1.ast;

public class DesignatorParens extends DesignatorOperations {

    private ActParsParen ActParsParen;

    public DesignatorParens (ActParsParen ActParsParen) {
        this.ActParsParen=ActParsParen;
        if(ActParsParen!=null) ActParsParen.setParent(this);
    }

    public ActParsParen getActParsParen() {
        return ActParsParen;
    }

    public void setActParsParen(ActParsParen ActParsParen) {
        this.ActParsParen=ActParsParen;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ActParsParen!=null) ActParsParen.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ActParsParen!=null) ActParsParen.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ActParsParen!=null) ActParsParen.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesignatorParens(\n");

        if(ActParsParen!=null)
            buffer.append(ActParsParen.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesignatorParens]");
        return buffer.toString();
    }
}
