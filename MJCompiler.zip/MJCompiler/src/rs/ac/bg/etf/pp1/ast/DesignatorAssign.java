// generated with ast extension for cup
// version 0.8
// 17/2/2022 21:43:24


package rs.ac.bg.etf.pp1.ast;

public class DesignatorAssign extends DesignatorOperations {

    private AssignopExpr AssignopExpr;

    public DesignatorAssign (AssignopExpr AssignopExpr) {
        this.AssignopExpr=AssignopExpr;
        if(AssignopExpr!=null) AssignopExpr.setParent(this);
    }

    public AssignopExpr getAssignopExpr() {
        return AssignopExpr;
    }

    public void setAssignopExpr(AssignopExpr AssignopExpr) {
        this.AssignopExpr=AssignopExpr;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(AssignopExpr!=null) AssignopExpr.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(AssignopExpr!=null) AssignopExpr.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(AssignopExpr!=null) AssignopExpr.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesignatorAssign(\n");

        if(AssignopExpr!=null)
            buffer.append(AssignopExpr.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesignatorAssign]");
        return buffer.toString();
    }
}
